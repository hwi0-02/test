package service;

import model.Book;

public interface BookService {
    Book getBookById(int id);
}
